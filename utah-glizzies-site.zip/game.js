const roster = window.siteContent.players.map(({ number, nameplate }) => ({ number, nameplate }));
const gameStats = window.siteContent.gameStats || {};
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const $ = (selector) => document.querySelector(selector);

const lines = {
  goal: [
    "The goalie needed Google Maps for that one.",
    "That puck had mustard on it.",
    "Goalie slid across like a fridge on wet tile.",
    "Buried. Absolutely processed meat behavior.",
  ],
  save: [
    "Saved. Sadly, the goalie discovered lateral movement.",
    "Denied. That shot had all bun, no dog.",
    "Goalie got a piece. Unfortunate competence.",
    "No goal. The scouting report says shoot literally anywhere else.",
  ],
  miss: [
    "Missed the net. Great velocity, suspicious geography.",
    "That one found the glass. The glass remains undefeated.",
    "Wide of the cage. The puck requested a forwarding address.",
    "No goal. The net was available for comment and felt ignored.",
  ],
  start: [
    "Breakaway time. Deke, shoot, embarrass.",
    "One-on-one. You versus a goalie with suspicious confidence.",
    "Crash the net. Protect the brand.",
    "The crowd wants mustard. Give them mustard.",
  ],
};

const state = {
  running: false,
  result: null,
  score: 0,
  round: 1,
  mustard: 100,
  facing: "right",
  player: { x: 50, y: 80 },
  goalieX: 50,
  puck: null,
  keys: {},
  skater: null,
};

const net = { left: 39, right: 61, line: 32 };

const skater = $("[data-skater]");
const goalie = $("[data-goalie]");
const puck = $("[data-puck]");
const overlay = $("[data-game-overlay]");
const message = $("[data-game-message]");
const playerSelect = $("[data-game-player-select]");
const leaderboard = $("[data-game-leaderboard]");

function playerKey(player, stat) {
  return `${gameStats.keyPrefix || "utahglizzies-breakaway-v1"}-${String(player.number).replace(/[^a-z0-9]/gi, "x")}-${String(player.nameplate).toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${stat}`;
}

async function statRequest(action, key) {
  if (!gameStats.apiBase) return 0;
  const response = await fetch(`${gameStats.apiBase}/${action}/${key}`);
  if (!response.ok) throw new Error("Stats service unavailable");
  const data = await response.json();
  return Number(data.value || data.count || 0);
}

async function recordStat(player, stat) {
  try {
    await statRequest("hit", playerKey(player, stat));
    renderLeaderboard();
  } catch {
    const localKey = `breakaway-${playerKey(player, stat)}`;
    localStorage.setItem(localKey, String((Number(localStorage.getItem(localKey)) || 0) + 1));
    renderLeaderboard();
  }
}

function pickPlayer() {
  const selected = playerSelect?.value;
  state.skater = roster.find((player) => `${player.number}-${player.nameplate}` === selected) || null;
  $("[data-game-nameplate]").innerHTML = state.skater
    ? `<strong>${state.skater.nameplate}</strong><span>#${state.skater.number}</span>`
    : `<strong>Choose skater</strong><span>Then start</span>`;
}

function renderPlayerSelect() {
  if (!playerSelect) return;
  playerSelect.innerHTML = `
    <option value="">Select your skater...</option>
    ${roster.map((player) => `<option value="${player.number}-${player.nameplate}">#${player.number} ${player.nameplate}</option>`).join("")}
  `;
  playerSelect.value = "";
}

async function getPlayerLedger(player) {
  try {
    const [goals, saves] = await Promise.all([
      statRequest("get", playerKey(player, "goals")),
      statRequest("get", playerKey(player, "saves")),
    ]);
    return { ...player, goals, saves };
  } catch {
    const goals = Number(localStorage.getItem(`breakaway-${playerKey(player, "goals")}`)) || 0;
    const saves = Number(localStorage.getItem(`breakaway-${playerKey(player, "saves")}`)) || 0;
    return { ...player, goals, saves };
  }
}

async function renderLeaderboard() {
  if (!leaderboard) return;
  const rows = await Promise.all(roster.map(getPlayerLedger));
  rows.sort((a, b) => b.goals - a.goals || (b.goals + b.saves) - (a.goals + a.saves));
  leaderboard.innerHTML = `
    <div class="leaderboard-row leaderboard-head"><span>Player</span><span>Goals</span><span>Stopped</span><span>Scoring %</span></div>
    ${rows.map((player) => {
      const shots = player.goals + player.saves;
      const pct = shots ? Math.round((player.goals / shots) * 100) : 0;
      return `<div class="leaderboard-row"><span>#${player.number} ${player.nameplate}</span><strong>${player.goals}</strong><strong>${player.saves}</strong><strong>${pct}%</strong></div>`;
    }).join("")}
  `;
}

function randomLine(type) {
  const list = lines[type];
  return list[Math.floor(Math.random() * list.length)];
}

function setMessage(text) {
  message.textContent = text;
}

function update() {
  $("[data-game-score]").textContent = state.score;
  $("[data-game-round]").textContent = state.round;
  $("[data-game-mustard]").textContent = Math.round(state.mustard);
  skater.src = `public/game/sprites/skater-${state.facing}.png`;
  skater.style.left = `${state.player.x}%`;
  skater.style.top = `${state.player.y}%`;
  goalie.style.left = `${state.goalieX}%`;
  const puckOffset = state.facing === "left" ? -7 : 8;
  if (state.puck) {
    puck.style.display = "block";
    puck.style.left = `${state.puck.x}%`;
    puck.style.top = `${state.puck.y}%`;
    puck.classList.toggle("is-mustard", state.puck.power);
  } else if (state.running && !state.result) {
    puck.style.display = "block";
    puck.style.left = `${state.player.x + puckOffset}%`;
    puck.style.top = `${state.player.y - 1}%`;
    puck.classList.remove("is-mustard");
  } else {
    puck.style.display = "none";
  }
}

function startRound(reset = false) {
  pickPlayer();
  if (!state.skater) {
    setMessage("Pick your skater first. No accidental Froman point farming on our watch.");
    overlay.innerHTML = `<h1>Choose Your Skater</h1><p>Select a Glizzy from the dropdown before starting the breakaway.</p><button class="button primary" data-start-game>Start Breakaway</button>`;
    overlay.classList.add("is-visible");
    $("[data-start-game]").addEventListener("click", () => startRound(true));
    return;
  }
  if (reset) {
    state.score = 0;
    state.round = 1;
  } else {
    state.round += 1;
  }
  state.running = true;
  state.result = null;
  state.mustard = reset ? 100 : state.mustard;
  state.facing = Math.random() > 0.5 ? "right" : "left";
  state.player = { x: 50, y: 80 };
  state.goalieX = 50;
  state.puck = null;
  if (playerSelect) playerSelect.disabled = true;
  setMessage(randomLine("start"));
  overlay.classList.remove("is-visible");
  update();
}

function endShot(result) {
  state.result = result;
  state.running = false;
  if (result === "goal") state.score += 1;
  recordStat(state.skater, result === "goal" ? "goals" : "saves");
  setMessage(randomLine(result));
  const title = result === "goal" ? "GOAL!" : result === "miss" ? "WIDE" : "SAVE";
  overlay.innerHTML = `<h1>${title}</h1><p>${message.textContent}</p><button class="button primary" data-next-breakaway>Next Breakaway</button>`;
  overlay.classList.add("is-visible");
  if (playerSelect) playerSelect.disabled = false;
  $("[data-next-breakaway]").addEventListener("click", () => startRound(false));
  update();
}

function deke(direction) {
  if (!state.running || state.result) return;
  state.facing = direction;
  state.player.x = clamp(state.player.x + (direction === "left" ? -13 : 13), 12, 88);
  state.mustard = clamp(state.mustard - 8, 0, 100);
  setMessage(direction === "left" ? "Deke left. Ankles have entered witness protection." : "Deke right. Goalie might need a software update.");
  update();
}

function shoot(power = false) {
  if (!state.running || state.puck || state.result) return;
  const puckOffset = state.facing === "left" ? -7 : 8;
  const isMustard = power && state.mustard >= 30;
  if (isMustard) state.mustard = clamp(state.mustard - 30, 0, 100);
  state.puck = { x: state.player.x + puckOffset, y: state.player.y - 7, speed: isMustard ? 9.5 : 7.5, power: isMustard };
  setMessage(isMustard ? "MUSTARD SHOT launched. Absolute condiment cannon." : "Shot away. Please respect the art.");
  update();
}

document.addEventListener("keydown", (event) => {
  const target = event.target;
  const isTyping = target && ["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(target.tagName);
  const gameKey = ["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.code) || ["w", "a", "s", "d", "q", "e", "f"].includes(event.key.toLowerCase());
  if (gameKey && !isTyping) event.preventDefault();
  state.keys[event.key.toLowerCase()] = true;
  if (!isTyping && event.code === "Space") shoot(false);
  if (!isTyping && event.key.toLowerCase() === "q") deke("left");
  if (!isTyping && event.key.toLowerCase() === "e") deke("right");
  if (!isTyping && event.key.toLowerCase() === "f") shoot(true);
});

document.addEventListener("keyup", (event) => {
  state.keys[event.key.toLowerCase()] = false;
});

$("[data-start-game]").addEventListener("click", () => startRound(true));
$("[data-deke-left]").addEventListener("click", () => deke("left"));
$("[data-deke-right]").addEventListener("click", () => deke("right"));
$("[data-shoot]").addEventListener("click", () => shoot(false));
$("[data-mustard]").addEventListener("click", () => shoot(true));

setInterval(() => {
  if (!state.running || state.result) return;
  if (state.keys.arrowleft || state.keys.a) {
    state.player.x -= 2.4;
    state.facing = "left";
  }
  if (state.keys.arrowright || state.keys.d) {
    state.player.x += 2.4;
    state.facing = "right";
  }
  if (state.keys.arrowup || state.keys.w) state.player.y -= 1.2;
  if (state.keys.arrowdown || state.keys.s) state.player.y += 0.7;
  state.player.y = clamp(state.player.y - 0.45, 38, 83);
  state.player.x = clamp(state.player.x, 12, 88);
  state.goalieX += (state.player.x + Math.sin(Date.now() / 340) * 7 - state.goalieX) * 0.08;
  state.mustard = clamp(state.mustard + 0.45, 0, 100);
  if (state.puck) {
    state.puck.y -= state.puck.speed;
    if (state.puck.y <= net.line) {
      const onNet = state.puck.x >= net.left && state.puck.x <= net.right;
      const blocked = Math.abs(state.puck.x - state.goalieX) < (state.puck.power ? 8.5 : 12.5);
      state.puck = null;
      endShot(onNet && !blocked ? "goal" : onNet ? "save" : "miss");
    }
  }
  update();
}, 30);

renderPlayerSelect();
playerSelect?.addEventListener("change", () => pickPlayer());
pickPlayer();
renderLeaderboard();
setMessage("Choose a skater, then start the breakaway. The ledger will only credit the player you selected.");
overlay.classList.add("is-visible");
update();
